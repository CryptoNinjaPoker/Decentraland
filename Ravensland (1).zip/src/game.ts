import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../689705e0-fff4-4b3a-b31a-98d8cc3230b8/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("models/GroundFloorSciFi_02/GroundFloorSciFi_02.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const treehouse = new Entity('treehouse')
engine.addEntity(treehouse)
treehouse.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
treehouse.addComponentOrReplace(transform3)
const gltfShape2 = new GLTFShape("models/TreeHouse_01/TreeHouse_01.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
treehouse.addComponentOrReplace(gltfShape2)

const signpostTree = new Entity('signpostTree')
engine.addEntity(signpostTree)
signpostTree.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(4.5, 0, 6),
  rotation: new Quaternion(-2.6932454408475602e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000004768371582, 1, 1.0000004768371582)
})
signpostTree.addComponentOrReplace(transform4)

const greenAcaciaTree = new Entity('greenAcaciaTree')
engine.addEntity(greenAcaciaTree)
greenAcaciaTree.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(11.5, 0, 4.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenAcaciaTree.addComponentOrReplace(transform5)
const gltfShape3 = new GLTFShape("models/Tree_Forest_Green_01/Tree_Forest_Green_01.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
greenAcaciaTree.addComponentOrReplace(gltfShape3)

const greenAcaciaTree3 = new Entity('greenAcaciaTree3')
engine.addEntity(greenAcaciaTree3)
greenAcaciaTree3.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(9, 0, 9.5),
  rotation: new Quaternion(-1.10062582369541e-15, -0.6343932747840881, 7.562556447737734e-8, 0.7730104327201843),
  scale: new Vector3(0.9999990463256836, 1, 0.9999990463256836)
})
greenAcaciaTree3.addComponentOrReplace(transform6)
greenAcaciaTree3.addComponentOrReplace(gltfShape3)

const greenAcaciaTree2 = new Entity('greenAcaciaTree2')
engine.addEntity(greenAcaciaTree2)
greenAcaciaTree2.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(5, 0, 10.5),
  rotation: new Quaternion(8.200945890261824e-15, -0.9951847195625305, 1.1863525628541538e-7, -0.09801722317934036),
  scale: new Vector3(0.9999998211860657, 1, 0.9999998211860657)
})
greenAcaciaTree2.addComponentOrReplace(transform7)
greenAcaciaTree2.addComponentOrReplace(gltfShape3)

const greenPoplars = new Entity('greenPoplars')
engine.addEntity(greenPoplars)
greenPoplars.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(2, 0, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars.addComponentOrReplace(transform8)
const gltfShape4 = new GLTFShape("models/TreeFir_02/TreeFir_02.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
greenPoplars.addComponentOrReplace(gltfShape4)

const greenPoplars2 = new Entity('greenPoplars2')
engine.addEntity(greenPoplars2)
greenPoplars2.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(4, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars2.addComponentOrReplace(transform9)
greenPoplars2.addComponentOrReplace(gltfShape4)

const greenPoplars4 = new Entity('greenPoplars4')
engine.addEntity(greenPoplars4)
greenPoplars4.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(14, 0, 8.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars4.addComponentOrReplace(transform10)
greenPoplars4.addComponentOrReplace(gltfShape4)

const greenPoplars6 = new Entity('greenPoplars6')
engine.addEntity(greenPoplars6)
greenPoplars6.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(6, 0, 1.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars6.addComponentOrReplace(transform11)
greenPoplars6.addComponentOrReplace(gltfShape4)

const greenPoplars7 = new Entity('greenPoplars7')
engine.addEntity(greenPoplars7)
greenPoplars7.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(14.5, 0, 1.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars7.addComponentOrReplace(transform12)
greenPoplars7.addComponentOrReplace(gltfShape4)

const greenPoplars3 = new Entity('greenPoplars3')
engine.addEntity(greenPoplars3)
greenPoplars3.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(13.5, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars3.addComponentOrReplace(transform13)
greenPoplars3.addComponentOrReplace(gltfShape4)

const greenPoplars5 = new Entity('greenPoplars5')
engine.addEntity(greenPoplars5)
greenPoplars5.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(6.5, 0, 4.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars5.addComponentOrReplace(transform14)
greenPoplars5.addComponentOrReplace(gltfShape4)

const greenPoplars8 = new Entity('greenPoplars8')
engine.addEntity(greenPoplars8)
greenPoplars8.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(9.5, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPoplars8.addComponentOrReplace(transform15)
greenPoplars8.addComponentOrReplace(gltfShape4)

const evergreenShrub = new Entity('evergreenShrub')
engine.addEntity(evergreenShrub)
evergreenShrub.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(10, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
evergreenShrub.addComponentOrReplace(transform16)
const gltfShape5 = new GLTFShape("models/Bush_03/Bush_03.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
evergreenShrub.addComponentOrReplace(gltfShape5)

const bush = new Entity('bush')
engine.addEntity(bush)
bush.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(13.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bush.addComponentOrReplace(transform17)
const gltfShape6 = new GLTFShape("models/Bush_02/Bush_02.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
bush.addComponentOrReplace(gltfShape6)

const shrub = new Entity('shrub')
engine.addEntity(shrub)
shrub.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(14, 0, 3.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
shrub.addComponentOrReplace(transform18)
const gltfShape7 = new GLTFShape("models/Bush_01/Bush_01.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
shrub.addComponentOrReplace(gltfShape7)

const evergreenShrub2 = new Entity('evergreenShrub2')
engine.addEntity(evergreenShrub2)
evergreenShrub2.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(2.5, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
evergreenShrub2.addComponentOrReplace(transform19)
evergreenShrub2.addComponentOrReplace(gltfShape5)

const evergreenShrub3 = new Entity('evergreenShrub3')
engine.addEntity(evergreenShrub3)
evergreenShrub3.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(7.5, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
evergreenShrub3.addComponentOrReplace(transform20)
evergreenShrub3.addComponentOrReplace(gltfShape5)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
script1.init(options)
script1.spawn(signpostTree, {"text":"See you inside!","fontSize":25}, createChannel(channelId, signpostTree, channelBus))